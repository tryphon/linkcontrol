require "active_form/spec_helper"
