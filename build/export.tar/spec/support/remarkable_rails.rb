# FIXME required with bundle and rails 2.3.5
require 'remarkable_rails'
