module NetworksHelper
end
