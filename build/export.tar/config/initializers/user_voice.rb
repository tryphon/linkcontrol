UserVoice.config do |account|
  account.key = 'tryphon'
  account.host = 'tryphon.uservoice.com'
  account.forum = '46947' 
  account.alignment = 'left'
  account.background_color = '#EA5D05' 
  account.text_color = 'white'
  account.hover_color = '#FF8F4A'
end
