class IncomingStream < LinkStream

  def puppet_configuration_prefix
    "link_incoming"
  end

end
